import { CustomInput } from './CustomInput';

export default CustomInput;
