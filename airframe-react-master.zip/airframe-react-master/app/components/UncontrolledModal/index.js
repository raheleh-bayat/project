import { UncontrolledModal } from './UncontrolledModal';
import { UncontrolledModalClose } from './UncontrolledModalClose';

UncontrolledModal.Close = UncontrolledModalClose;

export default UncontrolledModal;