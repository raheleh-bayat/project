import React from 'react';

const PageConfigContext = React.createContext();

export {
    PageConfigContext
};
