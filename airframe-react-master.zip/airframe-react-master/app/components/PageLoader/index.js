import PageLoader from './PageLoader';

export default PageLoader;