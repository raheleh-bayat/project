import { UncontrollerPopover } from './UncontrolledPopover';

export default UncontrollerPopover;