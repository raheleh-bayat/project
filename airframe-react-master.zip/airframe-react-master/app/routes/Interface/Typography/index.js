import Typography from './Typography';

export default Typography; 