import { Modals } from './Modals';

export default Modals;
