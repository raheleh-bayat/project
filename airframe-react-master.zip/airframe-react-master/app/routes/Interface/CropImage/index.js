import { CropImage } from './CropImage';

export default CropImage;
