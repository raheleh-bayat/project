import TooltipsPopovers from './TooltipsPopovers';

export default TooltipsPopovers; 