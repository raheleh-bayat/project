import { Images } from './Images';

export default Images;