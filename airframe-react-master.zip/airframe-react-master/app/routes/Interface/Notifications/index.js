import { Notifications } from './Notifications';

export default Notifications;
