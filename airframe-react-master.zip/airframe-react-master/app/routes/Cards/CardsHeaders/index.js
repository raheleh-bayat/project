import CardsHeaders from './CardsHeaders';

export default CardsHeaders; 