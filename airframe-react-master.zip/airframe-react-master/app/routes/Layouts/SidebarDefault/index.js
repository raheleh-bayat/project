import { SidebarDefault } from './SidebarDefault';

export default SidebarDefault;
