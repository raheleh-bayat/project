import { Sliders } from './Sliders';

export default Sliders;
