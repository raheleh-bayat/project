import { ExtendedTable } from './ExtendedTable';

export default ExtendedTable;
