import Danger from './Danger';

export default Danger;