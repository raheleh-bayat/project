import ComingSoon from './ComingSoon';

export default ComingSoon;