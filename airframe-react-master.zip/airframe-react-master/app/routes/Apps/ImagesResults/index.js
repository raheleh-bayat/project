import ImagesResults from './ImagesResults';

export default ImagesResults; 