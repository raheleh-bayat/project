import Inbox from './Inbox';

export default Inbox; 