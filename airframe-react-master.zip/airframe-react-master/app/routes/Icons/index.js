import Icons from './Icons';

export default Icons; 